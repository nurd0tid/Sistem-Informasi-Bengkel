#
# TABLE STRUCTURE FOR: details
#

DROP TABLE IF EXISTS `details`;

CREATE TABLE `details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `motor` varchar(250) NOT NULL,
  `jenisbarang` varchar(250) NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `tgl` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `motor` varchar(250) DEFAULT NULL,
  `kodepart` varchar(250) DEFAULT NULL,
  `jenisbarang` enum('Biasa','Original') DEFAULT NULL,
  `price` int(11) NOT NULL,
  `type` enum('service','sparepart','','') NOT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=483 DEFAULT CHARSET=latin1;

INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (25, 'Service Ringan Karburator', NULL, NULL, NULL, 40000, 'service', NULL);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (29, 'servis besar', NULL, NULL, NULL, 300000, 'service', NULL);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (32, 'servis injek', NULL, NULL, NULL, 45000, 'service', NULL);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (34, 'DISCPAD - H', 'BEAT, BEAT F1, VARIO, VARIO F1 125, VARIO CBS, SCOOPY F1, SONIC, ', 'KVY', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (35, 'DISCPAD - H', 'KARISMA , SUPRA-X 125 [DPN/BLK] , SUPRA , ', 'KPH', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (38, 'DISCPAD - S', 'SHOGUN, SHOGUN 125, SMASH, SKY WAVE', '32101', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (40, 'DISCPAD - S', 'SATRIA 150 FU [DPN] , SATRIA 2 TAK [DPN/BLK] ', '32101', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (42, 'DISCPAD - K', 'NINJA [ DPN/BLK ]', 'KWK', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (47, 'DISCPAD - H', 'VARIO 150 NEW , VARIO 125 NEW', 'KWN', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (49, 'DISCPAD - H', 'BLADE [DPN/BLK], REVO ABSOLUTE, REVO F1', 'KWB', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (54, 'DISCPAD - H', 'PCX NEW CBS [DPN]', '01', 'Biasa', 40000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (55, 'DISCPAD - H', 'PCX 150 NEW [BLK]', '02', 'Biasa', 35000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (56, 'DISCPAD - H ', 'CBR 250 [DPN/BLK]', '01', 'Biasa', 35000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (57, 'DISCPAD - Y', 'FORCE 1ZR, VEGA [R/ZR, JUPITER-Z, JUPITER MX, RX KING, SCORPIO, BYSON, VIXION  ', '01', 'Biasa', 23100, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (58, 'DISCPAD - Y', 'MIO, MIO SOUL, MIO J, ', '01', 'Biasa', 23100, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (59, 'DISCPAD - Y', 'N-MAX [DPN]', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (60, 'DISCPAD - Y', 'N-MAX [BLK]', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (61, 'DISCPAD - Y', 'MX KING [DPN/BLK], MIO-125 M3,', '01', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (62, 'DISCPAD - S', 'SATRIA-150 FU F1 [DPN/BLK]', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (63, 'DISCPAD - Y', 'R-15 NEW [DPN/BLK]', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (64, 'DISCPAD - Y', 'R - 25 NEW [DPN/BLK] ', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (65, 'DISCPAD - H', 'MEGA PRO, MEGAPRO NEW [DPN/BLK], TIGER, TIGER REVO [DPN/BLK], SONIC', '01', 'Biasa', 30000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (66, 'DISCPAD - Y', 'FORCE-1 ZR / VEGA / JUPITER-Z / NOUVO / RXK-NEW / SCORPIO ', '5TL', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (67, 'DISCPAD - Y', 'JUPITER MX / VEGA NEW / VEGA ZR / MIO SOUL / MIO-J / BYSON /VIXION / JUPITER Z NEW // N-MAX [BLK]', 'C11', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (68, 'DISCPAD - Y', 'RXS / RXK', 'RXK', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (69, 'DISCPAD - Y', 'R-15 NEW [BLK]', 'C11', 'Biasa', 25000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (70, 'DISCPAD - Y', 'R-25 NEW [DPN]', 'C11', 'Biasa', 35000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (71, 'DISCPAD - Y', 'R-25 [BLK]', 'C11', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (72, 'DISCPAD - Y', 'MIO', '5TL', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (73, 'DISCPAD - Y', 'MIO-125 / MX KING / [DPN] / N-MAX [DPN] ', 'C11', 'Biasa', 26000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (74, 'DISCPAD - S', 'SATRIA-150 FU /SPIN 125 / SUPRA-X 125 [BLK] / BLADE [BLK] / TIGER REVO [BLK] /JUPITER MX NEW [BLK] /MX KING [BLK] ', 'C11', 'Biasa', 24960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (75, 'DISCPAD - S', 'SATRIA-150 FU PGM-FI [DPN]', '3210133', 'Biasa', 27000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (76, 'DISCPAD - S', 'SATRIA-150 FU PGM-FI [BLK]', '3210133', 'Biasa', 29325, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (77, 'DISCPAD - S', 'THUNDER 125 / KLX-150 [DPN]', '3210133', 'Biasa', 21760, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (78, 'DISCPAD - S', 'NEX', '3210133', 'Biasa', 26720, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (79, 'KAMPAS BLK - H', 'GRAND / SUPRA', 'GN5', 'Biasa', 44000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (80, 'KAMPAS BLK - H', 'KARISMA / SUPRA-X 125 /REVO ABSOLUTE / BLADE', 'KPH', 'Biasa', 44000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (81, 'KAMPAS BLK - H', 'VARIO / BEAT /SCOPY / SPACY / MEGA PRO /TIGER NEW ', 'KZL', 'Biasa', 55000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (82, 'KAMPAS BLK - H', 'GLPRO / TIGER', 'KKW', 'Biasa', 55200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (83, 'KAMPAS BLK - Y', 'FORCE-1 / JUPITER-Z / VEGA / CRYPTON', '1S7', 'Biasa', 44000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (84, 'KAMPAS BLK - Y', 'VEGA-ZR', '71S', 'Original', 68000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (85, 'KAMPAS BLK  - Y', 'RXS / RXK / RXK NEW', 'C11', 'Original', 53920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (86, 'KAMPAS BLK  - S', 'NEX', 'C11', 'Biasa', 49600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (87, 'KAMPAS BLK - S', 'THUNDER 125 / SPIN / SKYWAVE / SKYDRIVE', 'C11', 'Biasa', 53920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (88, 'KAMPAS BLK - S', 'RC 100 / SHOGUN / SMASH / SHOGUN 125 / TORNADO', 'C11', 'Biasa', 44000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (89, 'K0NCI KONTAK - H', 'GRAND', 'GN5', 'Biasa', 56500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (90, 'KONCI KONTAK - H', 'SUPRA', 'GN5', 'Biasa', 56500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (91, 'KONCI KONTAK - H', 'LEGENDA', 'GN5', 'Biasa', 56500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (92, 'KONCI KONTAK - H', 'KARISMA', 'KPH', 'Biasa', 56500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (93, 'KONCI KONTAK - H ', 'BLADE', 'KWB', 'Biasa', 109100, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (94, 'KONCI KONTAK - H ', 'REVO', 'KWB', 'Biasa', 107800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (95, 'KONCI KONTAK - H ', 'REVO FIT', 'KWB', 'Biasa', 96250, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (96, 'KONCI KONTAK - H ', 'REVO ABSOLUTE', 'KWB', 'Biasa', 142500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (97, 'KONCI KONTAK - H ', 'SUPRA FIT NEW', 'KPH', 'Biasa', 56500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (98, 'KONCI KONTAK - H ', 'SUPRA FIT NEW [SC.LOCK]', 'KPH', 'Biasa', 107800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (99, 'KONCI KONTAK - H ', 'SUPRA-X 125', 'KPH', 'Biasa', 109100, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (100, 'KONCI KONTAK - H ', 'SUPRA-X 125 NEW', 'KPH', 'Biasa', 109100, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (101, 'KONCI KONTAK - H ', 'SUPRA-X 125 HELM IN [CRBU]', 'KPH', 'Biasa', 227200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (102, 'KONCI KONTAK - H ', 'SUPRA-X 125 HELM IN PGM FI', 'KPH', 'Biasa', 227200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (103, 'KONCI KONTAK - H ', 'BEAT', 'KVY', 'Biasa', 107800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (104, 'KONCI KONTAK - H ', 'VARIO', 'KZL', 'Biasa', 107800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (105, 'KONCI KONTAK - H ', 'VARI TECHNO', 'KVB', 'Biasa', 145000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (106, 'KONCI KONTAK - H ', 'VARI0 CBS', 'K44', 'Biasa', 145000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (107, 'KONCI KONTAK - H ', 'SCOOPY', 'K44', 'Biasa', 145000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (108, 'KONCI KONTAK - H ', 'GLPRO', 'KWB', 'Biasa', 68700, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (109, 'KONCI KONTAK - H ', 'GLPRO CDA', 'KWB', 'Biasa', 68700, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (110, 'KONCI KONTAK - H ', 'MEGA PRO 2010', 'KWB', 'Biasa', 74500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (111, 'KONCI KONTAK - H ', 'TIGER', 'KWB', 'Biasa', 74500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (112, 'KONCI KONTAK - H ', 'TIGER REVO NEW', 'KWB', 'Biasa', 75000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (113, 'KONCI KONTAK - Y', 'JUPITER Z', 'C11', 'Biasa', 75000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (114, 'KONCI KONTAK - Y', 'JUPITER MX', 'C11', 'Biasa', 79600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (115, 'KONCI KONTAK - Y', 'JUPITER MX NEW', 'C11', 'Biasa', 173250, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (116, 'KONCI KONTAK - Y', 'VEGA R NEW', 'C11', 'Biasa', 79600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (117, 'K0NCI KONTAK - Y', 'VEGA ZR', 'C11', 'Biasa', 84700, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (118, 'KONCI KONTAK - Y', 'RX-K / RX-S', 'C11', 'Biasa', 82200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (119, 'KONCI KONTAK - Y', 'RX-Z RX-K NEW', 'C11', 'Biasa', 82200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (120, 'KONCI KONTAK - Y', 'BYSON', 'C11', 'Biasa', 113000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (121, 'KONCI KONTAK - Y', 'SCORPIO-Z ', 'C11', 'Biasa', 83400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (122, 'KONCI KONTAK - Y', 'SCORPIO-Z NEW', 'C11', 'Biasa', 106500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (123, 'KONCI KONTAK - Y', 'VIXION', 'C11', 'Biasa', 106500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (124, 'KONCI KONTAK - Y', 'MIO', '5TL', 'Biasa', 79500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (125, 'KONCI KONTAK - Y', 'MIO SPORTY', '5TL', 'Biasa', 79600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (126, 'KONCI KONTAK - Y', 'MIO SOUL', '5TL', 'Biasa', 125800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (127, 'KONCI KONTAK - Y', 'MIO-J', '54P', 'Biasa', 205400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (128, 'KONCI KONTAK - Y', 'MIO-125 M3', '2PH', 'Biasa', 221400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (129, 'KONCI KONTAK - S', 'SATRIA', '310122', 'Biasa', 77000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (130, 'KONCI KONTAK - S', 'SATRIA-150 FU', '310122', 'Biasa', 93000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (131, 'KONCI KONTAK - S', 'AMASH', 'C11', 'Biasa', 77000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (132, 'KONCI KONTAK - S', 'SHOGUN / SHOGUN NEW', '310122', 'Biasa', 77000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (133, 'KONCI KONTAK - S', 'SHOGUN 125', '310122', 'Biasa', 116800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (134, 'KONCI KONTAK - S', 'SPIN 125', '310122', 'Biasa', 77000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (135, 'KONCI KONTAK - S', 'THUNDER 125', '3210122', 'Biasa', 96250, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (136, 'KONCI KONTAK - K', 'KAZE / FORCE-1ZR', 'KWK', 'Biasa', 79500, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (137, 'KABEL KOPLING - H', 'SUPRA XX', 'GN5', 'Biasa', 26800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (138, 'KABEL KOPLING - H', 'CS-1 ', 'KWC', 'Biasa', 24600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (139, 'KABEL KOPLING - H', 'WIN', 'GF6', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (140, 'KABEL KOPLING - H', 'GL 100', '397', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (141, 'KABEL KOPLING - H', 'GL PRO', 'KC5', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (142, 'KABEL KOPLING - H', 'MEGA PRO', 'KEH', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (143, 'KABEL KOPLING - H', 'MEGA PRO 2006', 'KEH', 'Biasa', 31600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (144, 'KABEL KPLING - H', 'MEGA PRO NEW 2011', 'KYE', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (145, 'KABEL KOPLING - H', 'TIGER', 'KCJ', 'Biasa', 31200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (146, 'KABEL KOPLING - H', 'TIGER NEW', 'KCJ', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (147, 'KABEL KOPLING - H', 'CBR-150-R', 'K15', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (148, 'KABEL KOPLING - H', 'FORCE-1ZR', '4WH', 'Biasa', 24800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (149, 'KABEL KOPLING - Y', 'JUPITER MX', '2S6', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (150, 'KABEL KOPLING - Y', 'JUPITER MX NEW', '50C', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (151, 'KABEL KOPLING - Y ', 'MX KING', '2VP', 'Biasa', 32800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (152, 'KABEL KOPLING - Y', 'RXS', 'C11', 'Biasa', 19200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (153, 'KABEL KOPLING - Y', 'RX-KING', 'C11', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (154, 'KABEL KOPLING - Y ', 'SCORPIO', '5BP', 'Biasa', 40000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (155, 'KABEL KOPLING - Y', 'VIXION', '3CL', 'Biasa', 25600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (156, 'KABEL KOPLING - Y', 'VIXION NEW', 'C11', 'Biasa', 24400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (157, 'KABEL KOLING - Y', 'BYSON', '45P', 'Biasa', 35200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (158, 'KABEL KOPLING - Y', 'R-15', 'C11', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (159, 'KABEL KOPLING - S', 'SHOGUN 125 SP ', '58200', 'Biasa', 27600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (160, 'KABEL KOPLING - S', 'SHOGUN 125 SP NEW', '58200', 'Biasa', 27600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (161, 'KABEL KOPLING - S', 'SATRIA', '58200', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (162, 'KABEL KOPLING - S', 'SATRIA 150 FU', '58200', 'Biasa', 32400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (163, 'KABEL KOPLING - S', 'SATRIA 150 FU PGM FI', '58200', 'Biasa', 29200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (164, 'KABEL KOPLING - S', 'THUNDER-125', '58200', 'Biasa', 37600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (165, 'KABEK KOPLING - K', 'KLX 150', 'KWK', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (166, 'NINJA', 'NINJA', 'KWK', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (167, 'KABEL KOPLING - K', 'NINJA RR', 'KWK', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (168, 'KABEL RPM - H', 'GL100 / GLK', '440', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (169, 'KABEL RPM - H', 'GL PRO', 'KC5', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (170, 'KABEL RPM - H', 'MEGA PRO 2006', 'KEH', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (171, 'KABEL RPM - Y', 'RX-KING', '29M', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (172, 'KABEL RPM - Y', 'SCORPIO', '5BP', 'Biasa', 31200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (173, 'KABEL RPM - S', 'THUDER 125', 'KWB', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (174, 'KABEL RPM - S', 'NINJA', 'KWK', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (175, 'KABEL RPM - K ', 'NINJA RR', 'KWK', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (176, 'KABEL REM - H', 'GRAND', 'GN5', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (177, 'KABEL REM - H', 'SUPRA', 'KEV', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (178, 'KABEL REM - H', 'KARISMA / SUPRA FIT NEW', 'KPH', 'Biasa', 41600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (179, 'KABEL REM - H', 'BEAT', 'KVY', 'Biasa', 52800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (180, 'KABEL REM - H', 'BEAT PGM FI', 'K25', 'Biasa', 44800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (181, 'KABEL REM - H', 'SCOOPY', 'KYT', 'Biasa', 64000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (182, 'KABEL REM - H', 'VZRIO', 'KVB', 'Biasa', 64000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (183, 'KABEL REM - H', 'VARIO PGM FI', 'KZR', 'Biasa', 45600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (184, 'KABEL REM - H', 'VARIO 150 PGM FI', 'K59', 'Biasa', 66400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (185, 'KABEL REM - H', 'GL 100 ', '439', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (186, 'KABEL REM -Y', 'MIO', '5TL', 'Biasa', 44800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (187, 'KABEL REM - Y', 'MIO J / SOUL GT', '54P', 'Biasa', 48800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (188, 'KABEL REM - Y', 'MIO VINO', '1UB', 'Biasa', 48800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (189, 'KABEL REM - Y', 'MIO VINO PGM FI NEW 125', 'BJ8', 'Biasa', 46400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (190, 'KABEL REM - Y', 'NOUVO', '5LW', 'Biasa', 64000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (191, 'KABEL REM - Y', 'NOUVO Z', '2DS', 'Biasa', 65600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (192, 'KABELREM - Y', 'XEON 125', '44D', 'Biasa', 49600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (193, 'KABEL REM - Y', 'AEROX', 'B65', 'Biasa', 60000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (194, 'KABEL REM - S', 'SHOGUN', '23F00L', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (195, 'KABEL REM - S', 'SMASH', 'B09G00N00', 'Biasa', 31200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (196, 'KABEL REM - S', 'SPIN', '23222', 'Biasa', 52800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (197, 'KABEL REM - S', 'NEX', '32333', 'Biasa', 57600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (198, 'KABEL REM - S', 'SKYDRIVE', 'B41120', 'Biasa', 72000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (199, 'KABEL REM - S', 'SKYWAVE', '13H00', 'Biasa', 82400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (200, 'KABEL REM - K', 'KAZE', 'KWK', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (201, 'KABEL SPEDOMETER - H', 'ASTREA / C700', 'GBO', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (202, 'KABEL SPEDOMETER - H', 'PRIMA', 'GN5', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (203, 'KABEL SPEDOMETER - H', 'GRAND', 'GN5', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (204, 'KABEL SPEDOMETER - H', 'SUPRA [TROMOL]', 'KEV', 'Biasa', 24800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (205, 'KABEL SPEDOMETER - H', 'SUPRA X ', 'KEV', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (206, 'KABEL SPEDOMETER - H', 'SUPRAFIT NEW', 'KTL', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (207, 'KABEL SPEDOMETER - H', 'BLADE / BLADE NEW', 'KWB', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (208, 'KABEL SPEDOMETER - H', 'REVO', 'KTM', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (209, 'KABEL SPEDOMETER - H', 'REVO ABSOLUTE', 'KWW', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (210, 'KABEL SPEDOMETER - H', 'BEAT', 'KVY', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (211, 'KABEL SPEDOMETER -H', 'VARIO', 'KVB', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (212, 'KABEL SPEDOMETER - H', 'GL100', '399', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (213, 'KABEL SPEDOMETER - H', 'GLPRO', 'KC6', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (214, 'KABEL SPEDOMETER - H', 'MEGA PRO / NEOTECH / TIGER', 'KEH', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (215, 'KABEL SPEDOMETER - H', 'MEGA PRO 2005', 'KEH', 'Biasa', 25600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (216, 'KABEL SPEDOMETER - H', 'MEGA PRO 2006', 'KEH', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (217, 'KABEL SPEDOMETER - H', 'TIGER NEW', 'KCJ', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (218, 'KABEL SPEDOMETER - Y', 'ALFA', '3AY', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (219, 'KABEL SPEDOMETER - Y', 'FORCE-1ZR', '4NS', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (220, 'KABEL SPEDOMETER - Y', 'JUPITER / VEGA / CRYPTON', '5LM', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (221, 'KABEL SPEDOMETER - Y', 'JUPITER Z', '5TP', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (222, 'KABEL SPEDOMETER - Y', 'JUPITER MX', '1S7', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (223, 'KABEL SPEDOMETER - Y', 'JUPITER MX NEW', '50C', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (224, 'KABEL SPEDOMETER - Y', 'JUPITER Z NEW 2011', '31B', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (225, 'KABEL SPEDOMETER - Y', 'JUPITER Z ONE [ INJECTION]', '1DY', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (226, 'KABEL SPEDOMETER - Y', 'VEGA Z R', '5D9', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (227, 'KABEL SPEDOMETER - Y', 'NOUVO', '5LW', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (228, 'KABEL SPEDOMETER - Y', 'NOUVO Z', '2D5', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (229, 'KABEL SPEDOMETER', 'MIO', '5TL', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (230, 'KABEL SPEDOMETER - Y', 'MIO VINO', '1UB', 'Biasa', 35200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (231, 'KSBEL SPEDOMETER - Y', 'MIO J / MIO SOUL GT', '54P', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (232, 'KABEL SPEDOMETER - Y', 'MIO SOUL', '14D', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (233, 'KABEL SPEDOMETER - Y', 'XEON 125', '44D', 'Biasa', 30800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (234, 'KABEL SPEDOMETER -Y', 'XEON RC', '1LB', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (235, 'KABEL SPEDOMETER - Y', 'X-RIDE', '2BU', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (236, 'KABEL SPEDOMETER - Y', 'RXK / RXS', '3KA', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (237, 'KABEL SPEDOMETER - Y', 'SCORPIO', '5BP', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (238, 'KABEL SPEDOMETER - Y', 'VIXION', '3C1', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (239, 'KABEL SPEDOMETER - S', 'SHOGUN NEW', '23F00L', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (240, 'KABEL SPEDOMETER - S', 'SMASH [DISC]', 'B09GI', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (241, 'KABEL SPEDOMETER - S', 'SMASH [TROMOL]', 'BO9GI', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (242, 'KABEL SPEDOMETER - S', 'SATRIA', 'B45H', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (243, 'KABEL SPEDOMETER - S', 'THUNDER 125', 'B45H', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (244, 'KABEL SPEDOMETER - S', 'SKYWAVE', '13H00', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (245, 'KABEL SPEDOMETER - S', 'SKYDRIVE', 'B41H', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (246, 'KABEL SPEDOMETER - S', 'SPIN', '46G11', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (247, 'KABEL SPEDOMETER - K', 'NINJA', 'KWK', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (248, 'KABEL SPEDOMETER - K', 'KLX 150', 'KWK', 'Biasa', 27200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (249, 'KABEL GAS - H', 'GRAND', 'GN5', 'Biasa', 19200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (250, 'KABEL GAS - H', 'SUPRA / REVO LAMA', 'KEV', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (251, 'KABEL GAS - H', 'KARISMA', 'KPH', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (252, 'KABEL GAS - H', 'SUIRA-X 125', 'KPH', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (253, 'KABEL GAS - H', 'SUPRA FIT NEW / REVO', 'KTL', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (254, 'KABEL GAS - H', 'SUPRA-X 125 PGM FI', 'KTM', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (255, 'KABEL GAS - H', 'SUPRA-X 125 HELM IN PGM FI', 'KYZ', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (256, 'KABEL GAS - H', 'SUPRA-X 125 HELM IN', 'KYZ', 'Biasa', 20800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (257, 'KABEL GAS - H', 'CS1', 'KWC', 'Biasa', 21600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (258, 'KABEL GAS - H', 'BLADE', 'KWB', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (259, 'KABEL GAS - H', 'REVO ABSOLUTE', 'KWW', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (260, 'KABEL GAS - H', 'REVO PGM FI', 'KO3', 'Biasa', 20000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (261, 'KABEL GAS - H', 'BEAT', 'KVY', 'Biasa', 36000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (262, 'KABEL GAS - H', 'BEAT PGM FI / SCOOPY PGM FI ', 'K44', 'Biasa', 38400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (263, 'KABEL GAS - H', 'BEAT POP PGM FI', 'KZL', 'Biasa', 51200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (264, 'KABEL GAS - H', 'SCOOPY NEW LED PGM FI', 'K81', 'Biasa', 51200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (265, 'KABEL GAS - H', 'SPACY', 'KZL', 'Biasa', 38400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (266, 'KABEL GAS - H', 'VARIO', 'KVB', 'Biasa', 36800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (267, 'KABEL GAS - H', 'VARIO PGM FI', 'KZR', 'Biasa', 39200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (268, 'KABEL GAS - H', 'VARIO 150 PGM FI', 'K59', 'Biasa', 51200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (269, 'KABEL GAS - H', 'GLK/GLMAX', 'KC6', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (270, 'KABEL GAS - H', 'GL PRO', 'KG2', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (271, 'KABEL GAS - H', 'VERZA (A)', 'K18', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (272, 'KABEL GAS - H', 'VERZA (B)', 'K18', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (273, 'KABEL GAS - H', 'MEGA PRO', 'KEH', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (274, 'KABEL GAS - H', 'MEGA PRO 2006', 'K18', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (275, 'KABEL GAS - H', 'MEGA PRO NEW 2011', 'KSP', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (276, 'KABEL GAS - H', 'PRO NEOTECH', 'KEH', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (277, 'KABEL GAS - H', 'TIGER (A)', 'KCJ', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (278, 'KABEL GAS - H', 'TIGER (B)', 'KCJ', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (279, 'KABEL GAS - H', 'TIGER NEW (A)', 'KCJ', 'Biasa', 31200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (280, 'KABEL GAS - H', 'TIGER NEW (B)', 'KCJ', 'Biasa', 31200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (281, 'KABEL GAS - H', 'TIGER REVO NEW (A)', 'KCJ', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (283, 'KABEL GAS - H', 'TIGER REVO NEW (B)', 'KCJ', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (285, 'KABEL GAS - H', 'CBR-150 R', 'KPP', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (287, 'KABEL GAS - H', 'CB-150 R (A)', 'K15', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (288, 'KABEL GAS - H', 'CB-150 R (A)', 'K15', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (289, 'KABEL GAS - H', 'CB-150 R (B)', 'K15', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (290, 'KABEL GAS - H', 'CB-150 R NEW (LED A)', 'K15', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (291, 'KABEL GAS - H', 'CB-150 R NEW (LED B)', 'K15', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (292, 'KABEL GAS - Y', 'V80/V75', '3ES', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (293, 'KABEL GAS - Y', 'ALFA', '3AY', 'Biasa', 29600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (294, 'KABEL GAS - Y', 'FORCE-1', '3XA', 'Biasa', 32800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (295, 'KABEL GAS - Y', 'FORCE-1ZR', '4US', 'Biasa', 32800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (296, 'KABEL GAS - Y', 'CRYPTON', '4ST', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (297, 'KABEL GAS - Y', 'VEGA', '5ER', 'Biasa', 21600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (298, 'KABEL GAS - Y', 'VEGA R NEW', '3SO', 'Biasa', 20800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (299, 'KABEL GAS - Y', 'VEGA ZR', '5D9', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (300, 'KABEL GAS - Y', 'XEON 125', '44D', 'Biasa', 97600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (301, 'KABEL GAS - Y', 'XEON RC', '1LB', 'Biasa', 112000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (302, 'KABEL GAS - Y', 'JUPITER/JUPITER Z', '5LM', 'Biasa', 20800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (303, 'KABEL GAS - Y', 'JUPITER MX', '1S7', 'Biasa', 40000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (304, 'KABEL GAS - Y', 'JUPITER MX NEW', '50C', 'Biasa', 54400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (305, 'KABEL GAS - Y', 'JUPITER Z NEW', '2P2', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (306, 'KABEL GAS - Y', 'JUPITER Z NEW 2011', '31B', 'Biasa', 23200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (307, 'KABEL GAS - Y', 'JUPITER Z1', '1DY', 'Biasa', 60000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (308, 'KABEL GAS - Y', 'MX-KING 150', 'SPV', 'Biasa', 56000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (309, 'KABEL GAS - Y', 'MIO', '5TL', 'Biasa', 40000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (310, 'KABEL GAS - Y', 'MIO J/SOUL GT', '54P', 'Biasa', 105600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (311, 'KABEL GAS - Y', 'MIO SOUL GT 125', 'SX', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (312, 'KABEL GAS - Y', 'MIO FINO NEW 125', 'BJ8', 'Biasa', 110400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (313, 'KABEL GAS - Y', 'NOUVO', '5LW', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (314, 'KABEL GAS - Y', 'NOUVO Z', '2DS', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (315, 'KABEL GAS - Y', 'N-MAX', '2DP', 'Biasa', 118400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (316, 'KABEL GAS - Y', 'AEROX', 'B65', 'Biasa', 105600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (317, 'KABEL GAS - Y', 'YL2G/YB', '212', 'Biasa', 28000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (318, 'KABEL GAS - Y', 'RXS/RX KING', '1TR', 'Biasa', 36000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (319, 'KABEL GAS - Y', 'RX-KING NEW', '2KA', 'Biasa', 39200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (320, 'KABEL GAS - Y', 'BYSON', '45P', 'Biasa', 32000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (321, 'KABEL GAS - Y', 'BYSON PGM FI (A)', '2UP', 'Biasa', 33600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (322, 'KABEL GAS - Y', 'BYSON PGM FI (B)', '2UP', 'Biasa', 24800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (323, 'KABEL GAS - Y', 'SCORPIO', '5BP', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (324, 'KABEL GAS - Y', 'SCORPIO Z NEW', '54D', 'Biasa', 32800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (325, 'KABEL GAS - Y ', 'VIXION', '3C1', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (326, 'KABEL GAS - Y', 'R-15', '2PK', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (327, 'KABEL GAS - S', 'THORNADO', '31CA', 'Biasa', 32800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (328, 'KABEL GAS - S', 'SMASH', 'B0900', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (329, 'KABEL GAS - S', 'SMASH', 'B0900', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (330, 'KABEL GAS - S', 'SHOGUN', '3008', 'Biasa', 21600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (331, 'KABEL GAS - S', 'SHOGUN NEW', '7878', 'Biasa', 24000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (332, 'KABEL GAS - S', 'SHOGUN 125 NEW', 'B16H', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (333, 'KABEL GAS - S', 'SATRIA', '21D1', 'Biasa', 30400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (334, 'KABEL GAS - S', 'SATRIA 150 FU', '25G00', 'Biasa', 26400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (335, 'KABEL GAS - S', 'SKYDRIVE', 'B41H00', 'Biasa', 42400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (336, 'KABEL GAS - S', 'SKYWAVE', 'B13H', 'Biasa', 38400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (337, 'KABEL GAS - S', 'SPIN', 'B46G', 'Biasa', 40000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (338, 'KABEL GAS - S', 'NEX', 'K18', 'Biasa', 44800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (339, 'KABEL GAS - S', 'THUNDER 125', 'C11', 'Biasa', 28800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (340, 'KABEL GAS - K', 'KAZE', 'KWK', 'Biasa', 22400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (341, 'KABEL GAS - K', 'NINJA RR', 'KWK', 'Biasa', 44800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (342, 'KABEL GAS - K', 'KLX 150', 'KWK', 'Biasa', 224000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (343, 'KOMSTIR - H', 'GRAND', 'GN5', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (344, 'KOMSTIR - H', 'SUPRA', 'GN5', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (345, 'KOMSTIR - H', 'KARISMA', 'KPH', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (346, 'KOMSTIR - H', 'SUPRA-X 125', 'KPH', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (347, 'KOMSTIR - H', 'REVO ABSOLUD', 'KWB', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (348, 'KOMSTIR - H', 'VARIO / BEAT', 'KVB', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (349, 'KOMSTIR - H', 'GL PRO / TIGER', 'KCJ', 'Biasa', 53440, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (350, 'KOMSTIR - H', 'MEGA PRO NEW 2010 [ MONOSHOCK]', 'C11', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (351, 'KOMSTIR - Y', 'JUPITER/ JUPITER Z / JUPITER MX /VEGA R NEW / VEGA ZR /MIO', '5TL', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (352, 'KOMSTIR - Y', 'NMAX', 'K18', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (353, 'KOMSTIR - Y', 'RX KING', 'C11', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (354, 'KOMSTIR - Y', 'SCORPIOZ', 'C11', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (355, 'KOMSTIR - Y', 'VIXION', '1C1', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (356, 'KOMSTIR - S', 'SMASH / SHOGUN / SKYDRIVE /SPIN / THUNDER 125', 'C11', 'Biasa', 59520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (357, 'KOMSTIR - S', 'SATRIA 150 FU', 'C11', 'Biasa', 65600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (358, 'KOMSTIR - K ', 'KLX 150', 'KWK', 'Biasa', 119040, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (359, 'FILTER UDARA - H', 'KARISMA / SUPRA-X 125', 'KPH', 'Biasa', 60900, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (360, 'FILTER UDARA - H', 'KARISMA / SUPRA-X 125', 'KPH', 'Biasa', 60900, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (361, 'FILTER UDARA - H', 'REVO ABSOLUDE / BALDE', 'KWB', 'Biasa', 56800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (362, 'FILTER UDARA - H', 'BLADE NEW PGM FI', 'KWB', 'Biasa', 56800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (363, 'FILTER UDARA - H', 'CS-1', 'KWB', 'Biasa', 52320, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (364, 'FILTER UDARA - H', 'SUPRA-X 125 HELM IN', 'KWB', 'Biasa', 59920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (365, 'FILTER UDARA - H', 'MEGA PRO 2011', 'C11', 'Biasa', 52350, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (366, 'FILTER UDARA - H', 'CB-R 150', 'KCJ', 'Biasa', 49280, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (367, 'FILTER UDARA - H', ' BEAT', 'KVY', 'Biasa', 50960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (368, 'FILTER UDARA - H', 'BEAT NEW PGM FI / SCOOPY NEW PGM FI', 'K44', 'Biasa', 63760, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (369, 'FILTER UDARA - H', 'SCOOPY', 'KVY', 'Biasa', 50960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (370, 'FILTER UDARA - H', 'SPACY', 'KZL', 'Biasa', 74960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (371, 'FILTER UDARA - H', 'VARIO', 'KVB', 'Biasa', 52320, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (372, 'FILTER UDARA - H', 'VARIO TECHNO PGM-FI', 'KVB', 'Biasa', 74960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (373, 'FILTER UDARA - Y', 'VEGA ZR', '5TP', 'Biasa', 55440, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (374, 'FILTER UDARA - Y', 'JUPITER Z', '5TP', 'Biasa', 43520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (375, 'FILTER UDARA - Y', 'JUPITER Z 1 2013 [INJRKTION]', '1C1', 'Biasa', 56480, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (376, 'FILTER UDARA - Y', 'JUPITER MX', 'CKJ', 'Biasa', 41920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (377, 'FILTER UDARA - Y', 'MX KING', '5TP', 'Biasa', 62800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (378, 'FILTER UDARA - Y', 'XEON 125', '54P', 'Biasa', 57920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (379, 'FILTER UDARA - Y', 'BYSON', 'CKJ', 'Biasa', 62800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (380, 'FILTER UDARA - Y', 'VIXION', '1C1', 'Biasa', 50960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (381, 'FILTER UDARA - Y', 'VIXION NEW 2013', 'C1C', 'Biasa', 55440, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (382, 'FILTER UDARA - Y', 'MIO / MIO SPORTY', '5TL', 'Biasa', 40480, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (383, 'FILTER UDARA - Y', 'MIO J', '54P', 'Biasa', 56800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (384, 'FILTER UDARA - Y', 'MIO SOUL', '5TL', 'Biasa', 47840, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (385, 'FILTER UDARA - Y', 'MIO-125 M3', '2PH', 'Biasa', 56800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (386, 'FILTER UDARA - Y', 'N-MAX', '29P', 'Biasa', 72000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (387, 'FILTER UDARA - S', 'SATRIA 150 / SATRIA 150 NEW', '10111', 'Biasa', 56000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (388, 'FILTER UDARA - Y', 'SHOGUN 125', 'S1S', 'Biasa', 59920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (389, 'FILTER UDARA - Y', 'SMASH', '123', 'Biasa', 59920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (390, 'FILTER UDARA - Y', 'SKYDRIVE', '123', 'Biasa', 59920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (391, 'FILTER UDARA - Y', 'SPIN / NEX', '123', 'Biasa', 59920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (392, 'CDI - H', 'GRAND', 'GN5', 'Biasa', 69760, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (393, 'CDI - H', 'SUPRA-X 125 /KARISMA', 'KPH', 'Biasa', 141600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (394, 'CDI - H', 'BEAT', 'KVY', 'Biasa', 292600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (395, 'CDI - Y', 'FORCE-1 ZR', '5TP', 'Biasa', 102400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (396, 'CDI - Y', 'VEGA ZR', '5TP', 'Biasa', 141600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (397, 'CDI - Y', 'JUPITER Z', '5TP', 'Biasa', 141600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (398, 'CDI - Y', 'JUPITER MX', '5TL', 'Biasa', 272000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (399, 'CDI - Y', 'MIO', '5TL', 'Biasa', 136800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (400, 'CDI - S', 'SMASH', '123', 'Biasa', 136480, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (401, 'CDI - S', 'SHOGUN 110', '123', 'Biasa', 136480, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (402, 'CDI - S', 'SATRIA 150', '123', 'Biasa', 136480, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (403, 'KIPROK - H', 'GRAND / SUPRA', 'GN5', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (404, 'KIPROK - H', 'KARISMA / SUPRA-X 125', 'KPH', 'Biasa', 125000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (405, 'KIPROK - H', 'BLADE / REVO ABSOLUDE', 'KWB', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (406, 'KIPROK - H', 'VARIO', 'KVB', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (407, 'KIPROK - H', 'TIGER', 'KCJ', 'Biasa', 123200, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (408, 'KIPROK - Y', 'FORCE-1 ZR', '4US', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (409, 'KIPROK - Y', 'JUPITER MX', '1S7', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (410, 'KIPROK - S', 'SMASH', 'B09G00N000', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (411, 'KIPROK - S', 'SHOGUN 125', 'B20G00N000', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (412, 'KIPROK - S', 'SATRIA 150 FU', '25G00', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (413, 'PULLEY LUAR - H', 'BEAT', 'KVY', 'Biasa', 93440, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (414, 'PULLEY LUAR - H', 'VARIO', 'KVB', 'Biasa', 162960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (415, 'PULLEY LUAR - H', 'BEAT PGM F1', 'K25', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (416, 'PULLEY LUAR - H', 'VARIO 125 PGM F1', 'KWN', 'Biasa', 186080, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (417, 'PULLEY LUAR - Y', 'MIO', '5TL', 'Biasa', 150400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (418, 'PULLEY LUAR - Y', 'FINO', '1UB', 'Biasa', 146880, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (419, 'PULLEY LUAR - Y', 'MIO GT', '54P', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (420, 'PULLEY LUAR - Y', 'MIO J', '54P', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (421, 'PULLEY LUAR - Y', 'MIO M3', '2PH', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (422, 'PULLEY LUAR - Y', 'XEON 125', '44D', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (423, 'PULLEY LUAR - Y', 'XEON RC', '1LB', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (424, 'PULLEY LUAR - Y', 'X-RIDE', '2BU', 'Biasa', 176960, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (425, 'PULLEY ONLY - H', 'VARIO', 'KVB', 'Biasa', 306560, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (426, 'PULLEY ONLY - H', 'BEAT', 'KVY', 'Biasa', 306560, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (427, 'PULLEY ONLY - H', 'BEAT PGM F1', 'K25', 'Biasa', 343520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (428, 'PULLEY ONLY - H', 'VARIO 125 PGM F1', 'KZR', 'Biasa', 363680, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (429, 'PULLEY ONLY - H', 'SCOOPY', 'KYT', 'Biasa', 306560, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (430, 'PULLEY ONLY - H', 'PCX 150', 'K59', 'Biasa', 362080, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (431, 'PULLEY ONLY - Y', 'MIO', '5TL', 'Biasa', 278400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (432, 'PULLEY ONLY - Y', 'MIO FINO', '5TP', 'Biasa', 278400, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (433, 'PULLEY ONLY - Y', 'MIO J', '54P', 'Biasa', 343520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (434, 'PULLEY ONLY - Y', 'MIO-125 M3', ' 2PH', 'Biasa', 343520, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (435, 'PULLEY ONLY - Y', 'N-MAX', '59K', 'Biasa', 381120, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (436, 'PULLEY ONLY - S', 'SKYDRIVE /SPIN', '123', 'Biasa', 325280, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (437, 'PULLEY ONLY - S', 'NEX', '123', 'Biasa', 389920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (438, 'ROLLER - H', 'BEAT', 'K44', 'Biasa', 57600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (439, 'ROLLER - H', 'BEAT POP / BEAT FI / SCOOPY FI', 'K44', 'Biasa', 66800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (440, 'ROLLER - H', 'PCX 150', 'K59', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (441, 'ROLLER - Y', 'MIO', '5TL', 'Biasa', 53920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (442, 'ROLLER - Y', 'MIO-J', '54P', 'Biasa', 53920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (443, 'ROLLER - Y', 'MIO-M3', '2PH', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (444, 'ROLLER - Y', 'MIO FINO', '5TL', 'Biasa', 57600, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (445, 'ROLLER - Y', 'MIO SOUL GT 125', '2PH', 'Biasa', 53920, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (446, 'ROLLER - Y', 'N-MAX / XEON 125', '2DP', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (447, 'ROLLER - S', 'SKYDRIVE / SPIN', '`123', 'Biasa', 68800, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (448, 'VANBEL -S', 'SPIN', '123', 'Biasa', 80000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (449, 'KAMAPAS GANDA - H', 'BEAT', 'K44', 'Original', 135000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (450, 'MANGKOK GANDA - H', 'BEAT', 'K16', 'Original', 120000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (451, 'VANBEL - Y', 'MIO', '5TL', 'Original', 85000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (452, 'VANBEL - H', 'BEAT', 'K44', 'Original', 100000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (453, 'SHOCK BLK - H', 'BEAT', 'KVY', 'Original', 230000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (454, 'PINGIAN DEPAN - H', 'BEAT', 'KVB', 'Biasa', 70000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (455, 'VANBEL - H', 'VARIO 125', 'KZR', 'Original', 140000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (456, 'VANBEL - Y', 'N-MAX', 'K59', 'Original', 125000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (457, 'VANBEL - Y', 'MIO M3', 'KPH', 'Original', 90000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (458, 'VER - H', 'BEAT', 'KVY', 'Original', 85000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (459, 'SHOCK BLK - H', 'BEAT F[', 'K44', 'Original', 200000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (460, 'SHOCK BLK - Y', 'MIO', '5TL', 'Original', 195000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (461, 'AS SHOCK - H', 'BEAT FI /VARIO 125', 'KZL', 'Biasa', 220000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (462, 'KAMPAS GANDA - Y', 'MIO J', '54P', 'Original', 235000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (463, 'KAMPAS GANDA - H', 'BEAT POP', 'KVB', 'Original', 130000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (464, 'KAMPAS GANDA - S', 'NEX', '`123', 'Original', 120000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (465, 'KAMPAS GANDA - S', 'NEX', '`123', 'Original', 120000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (466, 'KAMPAS GANDA - H', 'KARISMA / SUPRA-X 125', 'KPH', 'Original', 145000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (467, 'MANGKOK GANDA - ', 'VARIO 125', 'KZR', 'Original', 150000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (468, 'MANGKOK GANDA - Y', 'MIO', '5TL', 'Biasa', 90000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (469, 'KELAHER BACK CVT - H', 'BEAT ', 'K44', 'Original', 50000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (470, 'GIR SET - H', 'SUPRA-X125 / KARISMA', 'KPH', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (471, 'GER SET - H', 'GRAND / SUPRA X ', 'GN5', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (472, 'GER SET - H', 'BLADE / REVO ABSOLUDE ', 'KWB', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (473, 'GER SET - Y', 'VEGA R / JUPITER Z', '5TP', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (474, 'GEAR SET - S', 'SMASH', 'B28F60N', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (475, 'GEAR SET', 'SHOGUN 125', 'B60F', 'Biasa', 105000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (476, 'GEAR SET', 'SATRIA FI INJECTION', 'B25G70N', 'Biasa', 195000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (477, 'GEAR SET', 'SATRIA FU', 'B25G60N', 'Biasa', 195000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (478, 'GEAR SET', 'SATRIA R', '27000B', 'Biasa', 115000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (479, 'GEAR SET', 'THUNDER', '2700B', 'Biasa', 145000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (480, 'GEAR SET', 'SCORPIO', '5BP1', 'Biasa', 165000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (481, 'GEAR SET', 'SCORPIO Z', '5BP6', 'Biasa', 165000, 'sparepart', 0);
INSERT INTO `products` (`id`, `name`, `motor`, `kodepart`, `jenisbarang`, `price`, `type`, `stock`) VALUES (482, 'GEAR SET', 'SCORPIO Z 2012', '54D2', 'Biasa', 165000, 'sparepart', 0);


#
# TABLE STRUCTURE FOR: purchase
#

DROP TABLE IF EXISTS `purchase`;

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `total` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: shop_info
#

DROP TABLE IF EXISTS `shop_info`;

CREATE TABLE `shop_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `address` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `shop_info` (`id`, `name`, `address`) VALUES (1, 'mjm motor', 'Jl. meruya selatan ');


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `suppliers` (`id`, `name`, `address`, `telephone`) VALUES (1, 'Jhon Doe', 'Jalan Raya Mangga 2', '08982819689');
INSERT INTO `suppliers` (`id`, `name`, `address`, `telephone`) VALUES (2, 'Part One', 'Joglo', '08982819689');


#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('sparepart','service') NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `plat` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `password`) VALUES (1, 'admin', '$2y$10$3BbAWRAxBSMG8eWL1Q1XcORKVHb6Q0ARczZ8WdLzyYF3n68jK/QEC');


